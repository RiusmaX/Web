// ** I18N
Calendar._DN = new Array
("“ú",
 "ŒŽ",
 "‰Î",
 "…",
 "–Ø",
 "‹à",
 "“y",
 "“ú");
Calendar._MN = new Array
("1ŒŽ",
 "2ŒŽ",
 "3ŒŽ",
 "4ŒŽ",
 "5ŒŽ",
 "6ŒŽ",
 "7ŒŽ",
 "8ŒŽ",
 "9ŒŽ",
 "10ŒŽ",
 "11ŒŽ",
 "12ŒŽ");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "T‚ÌÅ‰‚Ì—j“ú‚ðØ‚è‘Ö‚¦";
Calendar._TT["PREV_YEAR"] = "‘O”N";
Calendar._TT["PREV_MONTH"] = "‘OŒŽ";
Calendar._TT["GO_TODAY"] = "¡“ú";
Calendar._TT["NEXT_MONTH"] = "—‚ŒŽ";
Calendar._TT["NEXT_YEAR"] = "—‚”N";
Calendar._TT["SEL_DATE"] = "“ú•t‘I‘ð";
Calendar._TT["DRAG_TO_MOVE"] = "ƒEƒBƒ“ƒhƒE‚ÌˆÚ“®";
Calendar._TT["PART_TODAY"] = " (¡“ú)";
Calendar._TT["MON_FIRST"] = "ŒŽ—j“ú‚ðæ“ª‚É";
Calendar._TT["SUN_FIRST"] = "“ú—j“ú‚ðæ“ª‚É";
Calendar._TT["CLOSE"] = "•Â‚¶‚é";
Calendar._TT["TODAY"] = "¡“ú";
 
// First day of the week. "0" means display Sunday first, "1" means display
// Monday first, etc.
Calendar._FD = 1;

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "y-mm-dd";
Calendar._TT["TT_DATE_FORMAT"] = "%mŒŽ %d“ú (%a)";

Calendar._TT["WK"] = "T";
