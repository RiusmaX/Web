<?php defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' ); ?>
positions=1
desc=M4J_LANG_DESC_LAYOUT01
