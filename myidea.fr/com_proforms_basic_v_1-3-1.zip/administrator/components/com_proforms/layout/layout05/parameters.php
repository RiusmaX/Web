<?php defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' ); ?>
desc=M4J_LANG_DESC_LAYOUT05
