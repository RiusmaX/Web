<?PHP
        /**
        * @Έκδοση $Id: proforms 10041 2008-03-18 21:48:13Z fahrettinkutyol $
        * @πακέτο joomla
        * @Δικαιώματα δημιουργού (C) 2008 Mad4Media. Όλα τα δικαιώματα είναι κατοχυρωμένα από την εταιρία.
        * @Άδεια http://www.gnu.org/copyleft/gpl.html GNU/GPL, βλέπε LICENSE.php
        * Το Joomla! είναι δωρεάν λογισμικό.Αυτή η έκδοση μπορεί να τροποποιηθεί σύμφωνα
        * με την γενική άδεια χρήσης GNU , η διανομή αυτή περιέχει παράγωγα ή κατοχυρωμένες
        * άδεις της GNU ή άλλα δωρεάν
        * ή open source άδειες χρήσεις λογισμικού.
        * Διαβάστε το COPYRIGHT.php για λεπτομέρειες.
        * @copyright (C) mad4media , www.mad4media.de
        */

        /**  ΕΛΛΗΝΙΚΗ ΜΕΤΑΦΡΑΣΗ ΠΡΟΣΑΡΜΟΓΗ ΓΙΑΝΝΗΣ ΣΦΕΤΚΟΣ */

        defined( '_JEXEC' ) or die( 'Απαγορεύεται η απευθείας πρόσβαση σε αυτό το σημείο.' );
?>


<table width="<?PHP echo  M4J_WORKAREA-36 ; ?>px" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>
        
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="300px" height="309" align="center" valign="top"><img src="components/com_proforms/images/proforms-image.jpg" width="253" height="309"></td>
        <td align="left" valign="top"><h3>Mooj Proforms Basic V <?PHP echo M4J_VERSION_NO; ?> | Build: <?PHP echo M4J_BUILD; ?> </h3>
          Αυτό το component δημιουργήθηκε από τον διπλωματούχο Informatiker (παρόμοιο με MSc) Fahrettin Kutyol για την Mad4Media.<br>
          Η Mad4Media δημιουργεί λογισμικό επικεντρωμένο σε συγκεκριμένες ανάγκες χρηστών. Τα προϊόντα μας είναι σχεδιασμένα και φιλικά προς τους χρήστες. Εκτος από τον προγραμματισμό Java and PHP προσφέρουμε εκτεταμένη ανάπτυξη του Joomla ή και του osCommerce για τους πελάτες μας. Εάν θέλετε περισσότερες πληροφορίες επικοινωνήστε μαζί μας μέσω της ιστοσελίδας μας: <a href="http://www.mad4media.de" target="_blank">Mad4Media</a><br>
          <br>
          <strong>License and Guarantee</strong><br>
          Mooj Proforms Basic is published under the GNU GPL license. There is no guarantee to functionality or completeness.  Mad4Media doesn't assume liability for damages caused by this component..<br>
          <br>
          <strong>Implemented Open Source Components:</strong><br>
          <a href="http://www.dynarch.com/projects/calendar/" target="_blank">jsCalendar</a> - LGPL<br>
          Icons from &copy; Mad4Media<br>
          
          <br>
          <br></td>
      </tr>
    </table>
        
            <table width="100%" border="0" cellspacing="10" cellpadding="0">
          <tr>
            <td width="50%" align="left" valign="top"><h3>Upgrade to PRO!</h3>
		      <a href="http://www.mad4software.com/packages/proforms.html" target="_blank">
				<img src="components/com_proforms/images/buy-proforms.png" >
			</a>
			<ul>
				<li>No Copyrightlink!</li>
				<li>Many additional functions</li>
				<li>Modules und plugins</li>
				<li>Database storage und backups</li>
				<li>Multilinguality</li>
				<li>Support</li>
				<li>Manuals via the Helpdesk</li>
				<li>Just install it over the Basic version and all forms will remain.</li>
				
			</ul>
			<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" height="100%" align="left" valign="top"><h3>Mooj Home</h3>
                  <p>Επαρκείς πληροφορίες θα βρείτε στην ιστοσελίδα μας στο mad4media.
                    <br />
                    Μπορείτε να κατεβάσετε και άλλα αρχεία μετάφρασης στην εξής σελίδα <br />
                    <a href="http://www.mooj.org" target="_blank">www.mooj.org
                  </a></p>
                  <p>Οι μεταφραστές θα λάβουν link της ιστοσελίδας τους. <br />
                  <h3>Μεταφράσεις</h3>
                    Αγγλικά στα γερμανικά από <a href="www.mad4media.de" target="_blank">mad4media</a><br />
                    Frontend Πορτογαλλία by <a href="mailto:tecnicoisaias@yahoo.com.br">Isaias Santana</a><br />
                                        Ισπανικά από <a href="http://www.virtualizza.es">Virtualizza</a><br />
                                        Frontend Φιλανδικά από  <a href="www.aktiivi.com">Niko Kotiniemi</a><br />
                                        Frontend Ελληνικά από <mailto:"sfetkos@yahoo.com"">Yannis Sfetkos/a><br />
                                        Frontend Νορβηγικά από <a href="http://www.mobbingiskolen.no">Mobbing I skolen</a><br />
                                        Frontend Κροατικά από  <a href="www.kk-fsv.hr">Damir</a><br />
                                        Frontend Catalan από  <a href="http://www.jordiborras.cat">Jordi Borras i Vivo</a><br />
                                        Frontend Πολωνικά από<a href="http://www.e-wolomin.pl">Przemyslaw Dmochowski</a><br />
                                        Frontend Σουηδικά από <a href="www.isajoh.se">Magnus Andersson</a><br />
                                        Frontend Δανέζικα από <a href="www.saft-computer.dk">Kristen Thiesen</a><br />
                    <br />
                </td>
              </tr>
              </table>                        <h3>&nbsp;</h3></td>
            <td width="52%" align="left" valign="top"><h3>Οδηγός εκκίνησης <br />
            </h3>
              <p><strong>Βήμα 1:</strong><br />
                Χρειάζεστε κατηγορία;? <br />
                π.χ. εάν θέλετε να δημοσιεύσετε μερικές αγγελίες εργασίας, σας συνηστούμε να δημιουργήσετε κατηγορία ονόματι &quot;Αγγελίες&quot;. Όταν εισάγετε κατηγορία μπορείτε να προσθέσετε περιεχόμενο το οποίο θα φαίνετα στην κεφαλίδα.
               <br />
                <br />
                <strong>Βήμα 2:</strong><br />
              Εφαρμοφή σε ένα η περισσότερα πρότυπα<br />
              Βάλτε μια σύντομη περιγραφή. Αυτό είναι για την αναγνώριση του προτύπου. Είναι πολύ σημαντικό να βάλετε διαστάσεις στις στήλες της φόρμας. Στο επόμενο πεδίο πρέπει να βάλετε πεδία στην φόρμα. Το κείμενο βοήθειας θα φαίνεται με το πέρασμα του ποντικιού. <br />
              <br />
                <strong>Βήμα 3:</strong><br />
                Εφαρμογή της φόρμας.<br />
                Εισάγετε τίτλο και ορίστε κατηγορία. Έαν δεν θέλετε να ορίσετε κατηγορία επιλέξτε &quot;Χωρίς κατηγορία&quot;.<br />
                Επιλέξτε πρότυπο. Εάν δεν βάλετε email τότε αυτά θα πηγαίνουν στα email των κατηγοριών. Εάν δεν υπάρχουν κατηγορίες θα πηγαίνουν στο κεντρικό.
                <br />
                Από κάτω &quot;captcha&quot;  μπορείτε να επιλέξετε ασφάλεια για να αποφύγετε το spam. <br />
                Το εισαγωγικό κείμενο το βλέπουν μόνο οι χρήστες. <br />
                Το κυρίως κείμενο φαίνεται μόνο στις λίστες των φορμών.<br />
                το εισαγωγικό Email κείμενο είναι για εσάς. Εμφανίζεται μόνο σαν απάντηση των emails.
				</p>
             </td>
          </tr>
      </table>      
      <p>&nbsp;</p></td>
  </tr>
</table>

